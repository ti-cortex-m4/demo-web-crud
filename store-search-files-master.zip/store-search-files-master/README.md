# store-search-files

Store and Search file with Spring Boot and Couchbase
